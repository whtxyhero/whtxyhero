
# Test environments passing
* Local: R version 3.4.3 (2017-11-30), x86_64-w64-mingw32 (64-bit)
* win-builder: , R Under development (unstable) (2018-01-04 r74054), x86_64-w64-mingw32(64-bit)
* travis-ci: R version 3.4.2 (2017-01-27), x86_64-pc-linux-gnu (64-bit), Ubuntu 14.04.5 LTS, R 3.4.1 
* AppVeyor: R version 3.4.3 Patched (2018-01-05 r74073), i386-w64-mingw32/i386 (32-bit), Windows Server 2012 R2 x64 (build 9600)


## Local R CMD check results
There were no ERRORs, WARNINGs or NOTEs
0 errors | 0 warnings | 0 notes
R CMD check succeeded


## win-builder
Status: 1 NOTE
Possibly mis-spelled words in DESCRIPTION: 
Econometrics (3:41)
Wooldridge (4:33, 23:14)
econometrics (8:45, 22:40)
wooldridge (10:60, 19:70)

## travis-ci
Done. Your build exited with 0.

## AppVeyor
Build success
  