#' crime2
#'
#' Wooldridge Source: These data were collected by David Dicicco, a former MSU undergraduate, for a final project. They came from various issues of the County and City Data Book, and are for the years 1982 and 1985. Unfortunately, I do not have the list of cities. Data loads lazily.
#'
#' @section Notes: Very rich crime data sets, at the county, or even city, level, can be collected using the FBI’s Uniform Crime Reports. These data can be matched up with demographic and economic data, at least for census years. The County and City Data Book contains a variety of statistics, but the years do not always match up. These data sets can be used investigate issues such as the effects of casinos on city or county crime rates.
#'
#' Used in Text: pages 313-314, 459-460
#'
#' @docType data
#'
#' @usage data('crime2')
#'
#' @format A data.frame with 92 observations on 34 variables:
#' \itemize{
#'  \item \strong{pop:} population
#'  \item \strong{crimes:} total number index crimes
#'  \item \strong{unem:} unemployment rate
#'  \item \strong{officers:} number police officers
#'  \item \strong{pcinc:} per capita income
#'  \item \strong{west:} =1 if city in west
#'  \item \strong{nrtheast:} =1 if city in NE
#'  \item \strong{south:} =1 if city in south
#'  \item \strong{year:} 82 or 87
#'  \item \strong{area:} land area, square miles
#'  \item \strong{d87:} =1 if year = 87
#'  \item \strong{popden:} people per sq mile
#'  \item \strong{crmrte:} crimes per 1000 people
#'  \item \strong{offarea:} officers per sq mile
#'  \item \strong{lawexpc:} law enforce. expend. pc, $
#'  \item \strong{polpc:} police per 1000 people
#'  \item \strong{lpop:} log(pop)
#'  \item \strong{loffic:} log(officers)
#'  \item \strong{lpcinc:} log(pcinc)
#'  \item \strong{llawexpc:} log(lawexpc)
#'  \item \strong{lpopden:} log(popden)
#'  \item \strong{lcrimes:} log(crimes)
#'  \item \strong{larea:} log(area)
#'  \item \strong{lcrmrte:} log(crmrte)
#'  \item \strong{clcrimes:} change in lcrimes
#'  \item \strong{clpop:} change in lpop
#'  \item \strong{clcrmrte:} change in lcrmrte
#'  \item \strong{lpolpc:} log(polpc)
#'  \item \strong{clpolpc:} change in lpolpc
#'  \item \strong{cllawexp:} change in llawexp
#'  \item \strong{cunem:} change in unem
#'  \item \strong{clpopden:} change in lpopden
#'  \item \strong{lcrmrt_1:} lcrmrte lagged
#'  \item \strong{ccrmrte:} change in crmrte
#' }
#' @source \url{https://www.cengage.com/cgi-wadsworth/course_products_wp.pl?fid=M20b&product_isbn_issn=9781111531041}
#' @examples  str(crime2)
"crime2"
 
 
