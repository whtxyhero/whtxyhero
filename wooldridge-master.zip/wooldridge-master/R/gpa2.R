#' gpa2
#'
#' Wooldridge Source: For confidentiality reasons, I cannot provide the source of these data. I can say that Data loads lazily.
#'
#' @section Used in Text: pages 106, 184, 208-209, 210-211, 221, 259, 262-263
#'
#' they come from a midsize research university that also supports men’s and women’s athletics at the Division I level.
#'
#' @docType data
#'
#' @usage data('gpa2')
#'
#' @format A data.frame with 4137 observations on 12 variables:
#' \itemize{
#'  \item \strong{sat:} combined SAT score
#'  \item \strong{tothrs:} total hours through fall semest
#'  \item \strong{colgpa:} GPA after fall semester
#'  \item \strong{athlete:} =1 if athlete
#'  \item \strong{verbmath:} verbal/math SAT score
#'  \item \strong{hsize:} size grad. class, 100s
#'  \item \strong{hsrank:} rank in grad. class
#'  \item \strong{hsperc:} high school percentile, from top
#'  \item \strong{female:} =1 if female
#'  \item \strong{white:} =1 if white
#'  \item \strong{black:} =1 if black
#'  \item \strong{hsizesq:} hsize^2
#' }
#' @source \url{https://www.cengage.com/cgi-wadsworth/course_products_wp.pl?fid=M20b&product_isbn_issn=9781111531041}
#' @examples  str(gpa2)
"gpa2"
 
 
