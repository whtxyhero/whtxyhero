#' fair
#'
#' Wooldridge Source: R.C. Fair (1996), “Econometrics and Presidential Elections,” Journal of Economic Perspectives 10, 89-102. The data set is provided in the article. Data loads lazily.
#'
#' @section Notes: An updated version of this data set, through the 2004 election, is available at Professor Fair’s web site at Yale University: http://fairmodel.econ.yale.edu/rayfair/pdf/2001b.htm. Students might want to try their own hands at predicting the most recent election outcome, but they should be restricted to no more than a handful of explanatory variables because of the small sample size.
#'
#' Used in Text: pages 362-363, 440, 442
#'
#' @docType data
#'
#' @usage data('fair')
#'
#' @format A data.frame with 21 observations on 28 variables:
#' \itemize{
#'  \item \strong{year:} 1916 to 1992, by 4
#'  \item \strong{V:} prop. dem. vote
#'  \item \strong{I:} =1 if demwh, -1 if repwh
#'  \item \strong{DPER:} incumbent running
#'  \item \strong{DUR:} duration
#'  \item \strong{g3:} avg ann grwth rte, prev 3 qrts
#'  \item \strong{p15:} avg ann inf rate, prev 15 qtrs
#'  \item \strong{n:} quarters of good news
#'  \item \strong{g2:} avg ann grwth rte, prev 2 qrts
#'  \item \strong{gYR:} ann grwth rte, prev year
#'  \item \strong{p8:} avg ann inf rate, prev 8 qtrs
#'  \item \strong{p2YR:} inf rte over 2 yr period
#'  \item \strong{Ig2:} I*g2
#'  \item \strong{Ip8:} I*p8
#'  \item \strong{demwins:} =1 if V > .5
#'  \item \strong{In:} I*n
#'  \item \strong{d:} =1 in 1920, 1944,1948
#'  \item \strong{Id:} I*d
#'  \item \strong{Ig3:} I*g3
#'  \item \strong{Ip151md:} I*p15*(1-d)
#'  \item \strong{In1md:} I*n*(1-d)
#' }
#' @source \url{https://www.cengage.com/cgi-wadsworth/course_products_wp.pl?fid=M20b&product_isbn_issn=9781111531041}
#' @examples  str(fair)
"fair"
 
 
