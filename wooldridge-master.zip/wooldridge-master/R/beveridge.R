#' beveridge
#'
#' Wooldridge  Data loads lazily.
#'
#' @section 
#'
#' 
#'
#' @docType data
#'
#' @usage data('beveridge')
#'
#' @format A data.frame with 135 observations on 8 variables:
#' \itemize{
#'  \item \strong{month:} dec 200 through feb 2012
#'  \item \strong{urate:} unemployment rate, percent
#'  \item \strong{vrate:} vacancy rate, percent
#'  \item \strong{t:} linear time trend
#'  \item \strong{urate_1:} L.urate
#'  \item \strong{vrate_1:} L.vrate
#'  \item \strong{curate:} D.urate
#'  \item \strong{cvrate:} D.vrate
#' }
#' @source \url{https://www.cengage.com/cgi-wadsworth/course_products_wp.pl?fid=M20b&product_isbn_issn=9781111531041}
#' @examples  str(beveridge)
"beveridge"
 
 
